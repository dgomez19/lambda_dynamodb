def dynamodb_events(event, context):
    print("HOLA MUNDO")
    print("HOLA MUNDO")
    print(event)
